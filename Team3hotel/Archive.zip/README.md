# Team 3 Hotel

Full submission for the Hotel Reservation Schema

General Notes: Had to do manual inserts due to issues with import in MySQLWorkBench, decided to just manually enter data until resolved. Was able to import some data. 

## File Path

### ERD_SQL
- Delvecchio_Jonathan-HotelERD.jpg
- Delvecchio_Jonathan-HotelDB.sql
- Delvecchio_Jonathan-HotelData.sql
- Team3-HotelQueries.sql

### Data
- Amentity.csv
- Guest.csv
- Reservation.csv
- Room.csv
- roomAmentities.csv
- RoomReservation.csv
- RoomType.csv

### Part 4 Results (5 omitted b/c no data to show)
- Q1.csv
- Q2.csv
- Q3.csv
- Q4.csv
- Q6.csv
- Q7.csv
